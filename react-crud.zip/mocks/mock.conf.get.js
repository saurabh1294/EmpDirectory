const CONFIG_GETS = {
  '/flickrHost/public/api/v1/getImages': 'http://localhost:3456/getImages'
};

module.exports = CONFIG_GETS;
